<?php include('header.php'); ?>
<style>
    .gif-bg{
        position: absolute;
        top:0;
        bottom:0;
        left:0;
        right:0;
        margin:auto;
        z-index: 1;
        height: 120vh;
        width: auto;
    }
    .bg-image{
        z-index: 2;
        opacity: .85;
    }
    .cover-inner{
        z-index: 3;
    }
    .ser-item{
        position: relative;
    }
    .textonowl{
        position: absolute;
        font-size: 1.5rem;
        color:#fff;
        left: 1rem;
        top: 0;
        bottom: 0;
        margin: auto;
        height: fit-content;
    }
    .service-carousel {
    max-width: 320px;
    }
    .services{
        display:flex;
        flex-wrap:wrap;
    }
    .services .owl-nav{
        display:none;
    }
    .services img{
        max-width:100%;
    }
    .service-1,.service-2,.service-3,.service-4{
        width:25%;
        position: relative;
        height:320px;
        overflow:hidden;
    }
    .service-3,.service-4{
        margin-left: -10%;
    }
    /* .owl-stage {
        transform: none !important;
    } */
    /* theme css */
.owl-theme .owl-nav {
  margin-top: 10px;
  text-align: center;
  -webkit-tap-highlight-color: transparent; }
  .owl-theme .owl-nav [class*='owl-'] {
    color: #FFF;
    font-size: 14px;
    margin: 5px;
    padding: 4px 7px;
    background: #D6D6D6;
    display: inline-block;
    cursor: pointer;
    border-radius: 3px; }
    .owl-theme .owl-nav [class*='owl-']:hover {
      background: #869791;
      color: #FFF;
      text-decoration: none; }
  .owl-theme .owl-nav .disabled {
    opacity: 0.5;
    cursor: default; }

.owl-theme .owl-nav.disabled + .owl-dots {
  margin-top: 10px; }

.owl-theme .owl-dots {
  text-align: center;
  -webkit-tap-highlight-color: transparent; }
  .owl-theme .owl-dots .owl-dot {
    display: inline-block;
    zoom: 1;
    *display: inline; }
    .owl-theme .owl-dots .owl-dot span {
      width: 10px;
      height: 10px;
      margin: 5px 7px;
      background: #D6D6D6;
      display: block;
      -webkit-backface-visibility: visible;
      transition: opacity 200ms ease;
      border-radius: 30px; }
    .owl-theme .owl-dots .owl-dot.active span, .owl-theme .owl-dots .owl-dot:hover span {
      background: #869791; }
</style>
<main class="container-fluid cover-container">
    <img src="./assets/img/circle-whiterotate.gif" alt="" class="gif-bg">
    <div class="bg-image" id="bg-image"></div>
    <div class="half-round-imgs">
        <img src="./assets/img/sun-round.png" alt="" class="lefttop">
        <img src="./assets/img/sun-round.png" alt="" class="rightbottom">
        <!-- <img src="./assets/img/sun-round.png" alt="" class="left-c-img">
        <img src="./assets/img/sun-round.png" alt="" class="right-c-img"> -->
    </div>
    <div class="cover-inner p-x-15">
        <div class="get-data">
            <div class="container">
                <div class="row">
                    <div class="col-12 services">
                        <div class="service-1">
                            <div class="service-carousel">
                                <div class="ser-item bounce2">
                                    <img src="./assets/img/serivce-owl.png">
                                    <div class="textonowl">
                                        Consulting
                                    </div>
                                </div>
                                <div class="ser-item bounce2">
                                    <img src="./assets/img/serivce-owl.png">
                                    <div class="textonowl">
                                        Implementation
                                    </div>
                                </div>
                                <div class="ser-item bounce2">
                                    <img src="./assets/img/serivce-owl.png">
                                    <div class="textonowl">
                                        TAC
                                    </div>
                                </div>
                                <div class="ser-item bounce2">
                                    <img src="./assets/img/serivce-owl.png">
                                    <div class="textonowl">
                                        Authorised Course
                                    </div>
                                </div>
                                <div class="ser-item bounce2">
                                    <img src="./assets/img/serivce-owl.png">
                                    <div class="textonowl">
                                        Emerging Technologies
                                    </div>
                                </div>
                                <div class="ser-item bounce2">
                                    <img src="./assets/img/serivce-owl.png">
                                    <div class="textonowl">
                                        Skill Development
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="service-2">
                            <img src="./assets/img/support-c.png" alt="">
                            <div class="textonowl">
                                Inflow Care
                            </div>
                        </div>
                        <div class="service-3">
                            <img src="./assets/img/professional-c.png" alt="">
                            <div class="textonowl">
                                Inflow Seal
                            </div>
                        </div>
                        <div class="service-4">
                            <img src="./assets/img/learning-c.png" alt="">
                            <div class="textonowl">
                                Inflow Academy
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <a href="" class="n-btn"><span>Services @ Inflow</span></a>
        </div>
    </div>
</main>
<?php include('footer.php'); ?>