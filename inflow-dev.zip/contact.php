<?php include('header.php'); ?>

<main class="container-fluid cover-container">
    <img src="./assets/img/circle-whiterotate.gif" alt="" class="gif-bg">
    <div class="bg-image" id="bg-image"></div>
    <div class="half-round-imgs cont-circle">
        <img src="./assets/img/sun-round.png" alt="" class="righttop">
        <img src="./assets/img/sun-round.png" alt="" class="leftbottom">
    </div>
    <div class="cover-inner contact p-x-15">
        <div class="container">
            <div class="row">
                <div class="get-data col-12">
                    <div class="typewriter">
                        <h2 class="blink-h"><span class="typeview" style="--n: 53;">OUR PRODUCTS<span class="blink-end"></span></span></h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php include('footer.php'); ?>