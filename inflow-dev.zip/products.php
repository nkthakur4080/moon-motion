<?php include('header.php'); ?>

<main class="container-fluid cover-container">
    <img src="./assets/img/circle-whiterotate.gif" alt="" class="gif-bg">
    <div class="bg-image" id="bg-image"></div>
    <div class="half-round-imgs">
        <img src="./assets/img/sun-round.png" alt="" class="righttop">
        <img src="./assets/img/sun-round.png" alt="" class="leftbottom">
    </div>
    <div class="cover-inner product p-x-15">
        <div class="container">
            <div class="row">
                <div class="get-data col-12">
                    <div class="typewriter">
                        <h2 class="blink-h"><span class="typeview" style="--n: 53;">OUR PRODUCTS<span class="blink-end"></span></span></h2>
                    </div>
                </div>
                <div class="col-12">
                    <p><b>Surveillance</b> describes security measures that are designed to deny access to unauthorized personnel (including attackers or even accidental intruders) from physically accessing a building, facility, resource, or stored information; and guidance on how to design structures to resist potentially hostile acts. Surveillance Systems & solutions form a crucial part of '<b>Inflow Technologies</b>' IT Infrastructure Products range and include the world's best partners and products to ensure a safer and secure world.</p>
                    <h4>Professional, Reliable & Affordable Surveillance Systems</h4>
                    <p>Our Surveillance valued partners include Gulf Security Systems, Axis Communications and Bosch Security Systems amongst others. The combined range of products cover fire alarm systems, fire network systems and other products such as video entry systems, electronic power meters, network video products and intrusion alarm systems.</p>
                </div>
            </div>
        </div>
    </div>
</main>
<?php include('footer.php'); ?>