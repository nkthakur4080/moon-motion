<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script src="./assets/js/main.js"></script>
<script>
    // document.getElementById('rotateBtn').addEventListener('click', function() {
    //     var bgImage = document.getElementById('bg-image');
    //     var currentDegree = bgImage.style.transform.replace(/[^\d.]/g, '') || 0;
    //     var newDegree = parseInt(currentDegree) + 180;
    //     bgImage.style.transform = 'rotate(' + newDegree + 'deg)';
    // });
    
</script>
</body>
</html>