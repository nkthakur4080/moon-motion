<?php include('header.php'); ?>
<main class="container-fluid cover-container">
    <!-- <img src="./assets/img/circle-whiterotate.gif" alt="" class="gif-bg"> -->
    <div class="bg-image" id="bg-image"></div>
    <div class="half-round-imgs">
        <img src="./assets/img/sun-round.png" alt="" class="top-c-img">
        <img src="./assets/img/sun-round.png" alt="" class="bottom-c-img">
        <img src="./assets/img/sun-round.png" alt="" class="left-c-img">
        <img src="./assets/img/sun-round.png" alt="" class="right-c-img">
    </div>
    <div class="cover-inner p-x-15">
        <div class="get-data typewriter">
            <h1><span class="typeview" style="--n: 53;">Enabling Resellers to Deliver and Customers to adopt to IT<span class="blink-end"></span></span></h1>
            <!-- <p class="lead">Click the button to rotate the background!</p> --><br><br>
            <a href="" class="n-btn n-btn-blue"><span>GET STARTED</span></a>
            <a href="" class="n-btn"><span>WITH INFLOW</span></a>
        </div>
    </div>
</main>
<?php include('footer.php'); ?>