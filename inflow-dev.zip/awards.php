<div class="row tab-content" id="tab4">
                <div class="get-data col-12">
                    <div class="typewriter">
                        <h2 class="blink-h"><a href="about.php"><span class="typeview back-icon" style="--n: 53;">Awards & Recognitions<span class="blink-end"></span></span></a></h2>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/award-1.jpg" alt="award 1" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/award-2.jpg" alt="award 2" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/award-3.jpg" alt="award 3" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/award-4.jpg" alt="award 4" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/award-5.jpg" alt="award 5" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/award-6.jpg" alt="award 6" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/award-7.jpg" alt="award 7" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/award-8.jpg" alt="award 8" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/award-9.jpg" alt="award 9" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture1.jpg" alt="Picture 1" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture2.jpg" alt="Picture 2" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture3.jpg" alt="Picture 3" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture4.jpg" alt="Picture 4" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture5.jpg" alt="Picture 5" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture6.jpg" alt="Picture 6" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture7.jpg" alt="Picture 7" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture8.jpg" alt="Picture 8" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture9.jpg" alt="Picture 9" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture10.jpg" alt="Picture 10" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture11.png" alt="Picture 11" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture12.png" alt="Picture 12" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture13.jpg" alt="Picture 13" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture14.jpg" alt="Picture 14" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture15.png" alt="Picture 15" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture16.png" alt="Picture 16" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture17.png" alt="Picture 17" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <!-- <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture18.jpg" alt="Picture 18" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div> -->
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture19.png" alt="Picture 19" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <!-- <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture20.jpg" alt="Picture 20" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div> -->
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture21.png" alt="Picture 21" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture22.png" alt="Picture 22" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <!-- <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture23.jpg" alt="Picture 23" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div> -->
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture24.png" alt="Picture 24" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture25.png" alt="Picture 25" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture26.png" alt="Picture 26" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-pro">
                        <img src="./assets/img/card-bg.jpg" alt="background-img" class="bg-img">
                        <img src="./assets/img/awards/Picture27.png" alt="Picture 27" class="card-img-award">
                        <div class="award-text">
                            <p><b>Best Distributor 2023 from Hanwha Vision</b></p>
                            <p>November 3 2023</p>
                        </div>
                    </div>
                </div>
            </div>